#ifndef _BUILTINCMD_H
#define _BUILTINCMD_H

int builtin(Command *cmd);
int cmdcd(Command *cmd);

#endif // _BUILTINCMD_H