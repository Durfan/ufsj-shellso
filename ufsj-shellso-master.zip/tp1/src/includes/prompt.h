#ifndef _PROMPT_H
#define _PROMPT_H

void prompt(void);
void currdir(void);
void initshell(void);

#endif // _PROMPT_H