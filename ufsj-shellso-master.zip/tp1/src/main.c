#include "./includes/main.h"

int main(void) {

	initshell(); //print inicial
	commandLoop(); //laço principal

	printf("Saindo...\n");
	return EXIT_SUCCESS;
}