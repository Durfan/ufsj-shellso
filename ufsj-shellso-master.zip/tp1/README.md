# Sistemas Operacionais - TP 1 / :shell: shellso

## Alpha Stage

![Captura](https://github.com/Durfan/ufsj-shellso/blob/master/docs/captura.png)
